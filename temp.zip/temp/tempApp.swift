//
//  tempApp.swift
//  temp
//
//  Created by administrator-zou on 2022/3/15.
//

import SwiftUI

@main
struct tempApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
