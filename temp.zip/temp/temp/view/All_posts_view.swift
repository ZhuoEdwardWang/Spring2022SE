//
//  All_posts.swift
//  temp
//
//  Created by administrator-zou on 2022/4/12.
//

import SwiftUI

struct All_posts_view: View {
    var body: some View {
        /*
        List(All_posts_model){
            Single_post_model in
            Single_post_view(single_post_model: Single_post_model)
        }.listStyle(PlainListStyle())
         */
        VStack {
            Divider()
            ScrollView(.vertical, showsIndicators: true){
                ForEach(All_posts_model){Single_post_model in
                    Single_post_view(single_post_model: Single_post_model).padding(.horizontal, 10.0)
                    Divider()
                }
            }
        }
    }
}

struct All_posts_Previews: PreviewProvider {
    static var previews: some View {
        All_posts_view()
    }
}
