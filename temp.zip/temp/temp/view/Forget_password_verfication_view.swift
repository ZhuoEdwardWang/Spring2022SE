//
//  Forget_password_verfication_view.swift
//  temp
//
//  Created by administrator-zou on 2022/3/27.
//

import SwiftUI

struct Forget_password_verfication_view: View {
    @State private var verification_code: String = ""
    var body: some View {
        VStack{
            Spacer().frame(height:75)
            VStack(spacing: 20.0){
                Text("Please enter your verification code").font(.title3)
                VStack {
                    Divider()
                    HStack(spacing: 10.0) {
                        Text("Code:").font(.body).lineLimit(1).frame(alignment: .leading)
                        TextField("Enter email", text: $verification_code)
                            .font(.body)
                            .lineLimit(1)
                    }
                    Divider()
                }
            }
            Spacer()
            Button("Continue") {
                
            }.button_big()
            
            Spacer().frame(height:75)
        }
        .padding(.horizontal, 20.0)
    }
}

struct Forget_password_verfication_view_Previews: PreviewProvider {
    static var previews: some View {
        Forget_password_verfication_view()
    }
}
