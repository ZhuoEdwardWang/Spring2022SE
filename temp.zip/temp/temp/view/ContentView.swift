//
//  ContentView.swift
//  temp
//
//  Created by administrator-zou on 2022/3/15.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView { // 1
            ScrollView(){
                
                NavigationLink(destination: Integrate_view()) {
                    Text("Hello, World!")
                }
                
                HStack {
                    NavigationLink(destination: Integrate_view()) {
                        Text("Hello, World!")
                    }
                    
                    NavigationLink(destination: Login_view()) {
                        Text("Hello, World2!")
                        Text("Hello, World!")
                        
                        
                        
                        Text("Hello, World!")
                        Text("Hello, World!")
                        
                        
                        
                        Text("Hello, World!")
                
                    }
                    Text("Hello, World!")
                    
                    
                    
                    Text("Hello, World!")
                    Text("Hello, World!")
                    
                    
                    
                    Text("Hello, World!")
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            
            
    }
}
