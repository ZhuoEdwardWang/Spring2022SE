//
//  Forget_password_view.swift
//  temp
//
//  Created by administrator-zou on 2022/3/27.
//

import SwiftUI

struct Forget_password_view: View {
    @State private var email_address: String = ""
    var body: some View {
        VStack{
            Spacer().frame(height:75)
            VStack(spacing: 20.0){
                Text("Please enter your email").font(.title3)
                
                VStack {
                    Divider()
                    HStack(spacing: 10.0) {
                        Text("Email:").font(.body).lineLimit(1).frame(alignment: .leading)
                        TextField("Enter email", text: $email_address)
                            .font(.body)
                            .lineLimit(/*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                    }
                    Divider()
                }
            }
            Spacer()
            Button("Continue") {
                
            }.button_big()
            
            Spacer().frame(height:75)
        }
        .padding(.horizontal, 20.0)
    }
}

struct Forget_password_view_Previews: PreviewProvider {
    static var previews: some View {
        Forget_password_view()
    }
}
