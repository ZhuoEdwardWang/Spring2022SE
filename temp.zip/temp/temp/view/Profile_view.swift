//
//  Profile_view.swift
//  temp
//
//  Created by administrator-zou on 2022/3/26.
//

import SwiftUI

struct Profile_view: View {
    var user_profile: User_model
    var body: some View {
        
        VStack{
            Spacer().frame(height:75)
            
            VStack(spacing: 30.0) {
                user_profile.user_profile_picture.resizable(resizingMode: .stretch).aspectRatio(contentMode: .fit).frame(width:150).clipShape(Circle())
                Text(user_profile.user_name).font(.title)
            }
            Spacer()
            
            Text("Message").foregroundColor(.white).frame(width:200,height: 50).background(.blue).cornerRadius(8).font(.body)
            
            Spacer().frame(height:75)
        }
        
        
    }
}

struct Profile_view_Previews: PreviewProvider {
    static var previews: some View {
        Profile_view(user_profile: User_model(0))
    }
}
