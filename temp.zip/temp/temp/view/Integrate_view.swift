//
//  Integrate_view.swift
//  temp
//
//  Created by administrator-zou on 2022/4/11.
//

import SwiftUI

struct Integrate_view: View {
    
    @State var tab_selection: Tabs = .tab1
    var body: some View {
        NavigationView{
            
            TabView(selection: $tab_selection){
                Contacts().tabItem {
                    Label("Message", systemImage: "message.fill")
                }.tag(Tabs.tab1)
                
                Moments().tabItem {
                    Image(systemName: "location.circle")
                    Text("Discover")
                }.tag(Tabs.tab2)
                
                Text("Setting").tabItem {
                    Label("Setting", systemImage: "person.fill")
                }.tag(Tabs.tab3)
                
                
            }.font(.headline).navigationBarTitle(get_title(selected_tab: tab_selection),displayMode: .inline)
        
        }
        
        
    }
    
    enum Tabs{
        case tab1, tab2, tab3
    }

    func get_title(selected_tab:Tabs) -> String{
        switch selected_tab {
            case .tab1:
                return "Chat"
            case .tab2:
                return "Moment"
            case .tab3:
                return "Setting"
        }
            
    }
    
}

struct Integrate_view_Previews: PreviewProvider {
    static var previews: some View {
        Integrate_view()
    }
}
