//
//  Message_history_page_view.swift
//  temp
//
//  Created by administrator-zou on 2022/4/26.
//

import SwiftUI

struct Message_history_page_view: View {
    var chat_history: Single_chat_history_model
    @State var message: String = ""
    var body: some View {
        VStack {
            Single_chat_history_view(single_chat_history_model: chat_history)
            Spacer()
            TextField("", text: $message).padding(.all, 20.0).frame(height: 50).textFieldStyle(RoundedBorderTextFieldStyle()).default_color()
        }.default_color()
    }
}

struct Message_history_page_view_Previews: PreviewProvider {
    static var previews: some View {
        Message_history_page_view(chat_history:all_chat_message_model[0])
    }
}
