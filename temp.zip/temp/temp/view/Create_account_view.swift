//
//  Forget_pass_word_view.swift
//  temp
//
//  Created by administrator-zou on 2022/3/27.
//

import SwiftUI

struct Create_account_view: View {
    var body: some View {
        VStack{
            Spacer().frame(height:75)
            
            VStack(spacing: 50.0){
                Text("Create New Account").font(.title3)
                VStack {
                    Email_password_view()
                }
            }
            Spacer()
            
            Button("Create") {
                
            }.button_big()
            
            Spacer().frame(height:75)
            
        }.padding(.horizontal, 20.0)
        
    }
}

struct Create_account_view_Previews: PreviewProvider {
    static var previews: some View {
        Create_account_view()
    }
}
