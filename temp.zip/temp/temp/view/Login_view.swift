//
//  login_page.swift
//  temp
//
//  Created by administrator-zou on 2022/3/17.
//

import SwiftUI

struct Login_view: View {
    var body: some View {
        NavigationView {
            VStack(alignment: .center) {
                //Spacer().frame(height:75)
                
                VStack(spacing: 20.0){
                    Image("次生银翼").resizable(resizingMode: .stretch).aspectRatio(contentMode: .fit).frame(width:150, height: 150)
                    
                    VStack {
                        Email_password_view()
                        
                        HStack {
                            NavigationLink(destination: Forget_password_view()) {
                                Text("Forget password").font(.footnote).foregroundColor(.black)}
                            
                            
                            Spacer()
                            
                            NavigationLink(destination: Create_account_view()) {
                                Text("New account").foregroundColor(.black).font(.footnote)
                            }
                        }
                    }
                }
                Spacer()
                
                Button("Log in") {
                    
                }.button_big()
                
                Spacer().frame(height:75)
                
            }.padding(.horizontal, 20.0)
        }
        
    }
}

/*
struct enter_filed: View{
    @State private var email_address: String = ""
    @State private var password: String = ""
    var body: some View {
        VStack(alignment: .center, spacing: 50.0) {
            
            Image("次生银翼").resizable(resizingMode: .stretch).aspectRatio(contentMode: .fit).frame(width:150)
            
            VStack {
                Divider()
                HStack(spacing: 10.0) {
                    Text("Email:").font(.footnote).lineLimit(1).frame(width:70,alignment: .leading)
                    TextField("Enter email", text: $email_address)
                        .font(.footnote)
                        .lineLimit(/*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                }
                Divider()
                    
                HStack(spacing: 10.0) {
                    Text("Password:").font(.footnote).lineLimit(1).frame(width:70,alignment:.leading)
                    TextField("Enter password", text: $password)
                        .font(/*@START_MENU_TOKEN@*/.footnote/*@END_MENU_TOKEN@*/)
                        .lineLimit(/*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                }
                Divider()
                HStack {
                    Button("Forget password") {
                        
                    }.font(.caption2).foregroundColor(.black)
                    Spacer()
                    Button("New account") {
                        
                    }.foregroundColor(.black).font(.caption2)
                }
            }
            
            
            Button("Log in") {
                
            }.foregroundColor(.white).frame(width:200,height: 30).background(.brown).cornerRadius(8).font(.body)
            
        }
    }
}
 */
struct Login_page_Previews: PreviewProvider {
    static var previews: some View {
        Login_view()
    }
}
