//
//  Email_password_view.swift
//  temp
//
//  Created by administrator-zou on 2022/3/27.
//

import SwiftUI

struct Email_password_view: View {
    @State private var email_address: String = ""
    @State private var password: String = ""
    var body: some View {
        VStack {
            Divider()
            HStack(spacing: 10.0) {
                Text("Email:").font(.body).lineLimit(1).frame(width:100,alignment: .leading)
                TextField("Enter email", text: $email_address)
                    .font(.body)
                    .lineLimit(1)
            }
            Divider()                
            HStack(spacing: 10.0) {
                Text("Password:").font(.body).lineLimit(1).frame(width:100,alignment:.leading)
                TextField("Enter password", text: $password)
                    .font(.body)
                    .lineLimit(1)
            }
            Divider()
        }

    }
}

struct Email_password_view_Previews: PreviewProvider {
    static var previews: some View {
        Email_password_view()
    }
}
