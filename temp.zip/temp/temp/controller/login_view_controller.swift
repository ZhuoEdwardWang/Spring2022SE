//
//  login_view_controller.swift
//  temp
//
//  Created by administrator-zou on 2022/4/11.
//

import Foundation

func login(_ email:String, _ password: String) -> Bool {
    var output = true
    let email_existence = check_email_existence(email)
    output = output && email_existence
    let match = check_email_password_match(email, password)
    output = output && match
    return output
}
