//
//  Single_chat_history.swift
//  temp
//
//  Created by administrator-zou on 2022/3/26.
//

import Foundation
import SwiftUI
struct Single_chat_history_model: Identifiable{
    //Not the user Id, not the other ID, it's the ID of the chat message
    //Each communication between two users should have a distinct ID
    var id: Int
    var chat_name: String
    var chat_picture: Image
    //This two ID will be modified later
    //Each user should have distinct user ID
    
    /*
    var user_id: Int = 0
    var the_other_id: Int = 1
    
    var user_name: String
    var the_other_name: String
    
    private var user_picture_name: String
    private var the_other_picture_name: String
    
    var user_profile_picture: Image {
        Image(user_picture_name)
    }
    var the_other_picture: Image{
        Image(the_other_picture_name)
    }
    */
    
    var single_chat_history: [Single_chat_message_model]
    
    //should be modified later to assign user id
    init(_ id : Int, _ single_chat_history: [Single_chat_message_model]) {
        self.id = id
        self.chat_name = get_chat_name_from_chat_id(id)
        //self.user_name = user_name
        //self.the_other_name = the_other_name
        //self.user_picture_name = user_picture_name
        //self.the_other_picture_name = the_other_picture_name
        self.chat_picture = get_chat_picture_from_chat_id(id)
        self.single_chat_history = single_chat_history
    }
    
    /*
     //should be modified later to assign user id
     init(_ id : Int, _ user_name: String, _ the_other_name: String, _ user_picture_name: String, _ the_other_picture_name:String, _ single_chat_history: [Single_chat_message_model]) {
         self.id = id
         //self.user_name = user_name
         //self.the_other_name = the_other_name
         //self.user_picture_name = user_picture_name
         //self.the_other_picture_name = the_other_picture_name
         self.single_chat_history = single_chat_history
     }
     */
}



