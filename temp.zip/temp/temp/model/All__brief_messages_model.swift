//
//  All_messages.swift
//  temp
//
//  Created by administrator-zou on 2022/3/26.
//

import Foundation
var All_brief_messages_model: [Single_brief_message_model] = load_messages(all_chat_message_model)

func load_messages (_ all_chat_history: [Single_chat_history_model]) -> [Single_brief_message_model] {
    var output: [Single_brief_message_model] = []
    for single_chat_history in all_chat_history{
        
        let temp = Single_brief_message_model(
                            single_chat_history.id,
                            single_chat_history.chat_name,
                            single_chat_history.single_chat_history.last!.message,
                            single_chat_history.single_chat_history.last!.time,
                            single_chat_history.chat_picture)
        
        
        output.append(temp)
    }
    return output
}
            
            

/*
//This part will be revised to achieve actual data later
func load_messages () -> [Single_message_model] {
    return [Single_message_model(0,"Bronya","orrupt binary codes infecting my mind, perform invocation with numbing freeze","18:18", "次生银翼"),
            Single_message_model(1,"Bronya","orrupt binary codes infecting my mind, perform invocation with numbing freeze","18:18", "次生银翼"),
            Single_message_model(2,"Bronya","orrupt binary codes infecting my mind, perform invocation with numbing freeze","20:20", "次生银翼"),
            Single_message_model(3,"Bronya","orrupt binary codes infecting my mind, perform invocation with numbing freeze","19:18", "次生银翼"),
            Single_message_model(4,"Bronya","orrupt binary codes infecting my mind, perform invocation with numbing freeze","06:54", "次生银翼"),
    ]
}
*/
