//
//  single_chat_message_model.swift
//  temp
//
//  Created by administrator-zou on 2022/3/26.
//

import Foundation
import SwiftUI
struct Single_chat_message_model:Identifiable{
    //The No.
    var id: Int
    
    //true means from the user
    //false means from the others
    var sender_id: Int
    var message: String
    //Type can be changed later
    var time: Date
    
    init(_ id: Int, _ type: Int, _ message: String, _ time: Date) {
        self.id = id
        self.sender_id = type
        self.message = message
        self.time = time
    }
}

