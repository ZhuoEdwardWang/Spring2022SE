//
//  File.swift
//  temp
//
//  Created by administrator-zou on 2022/3/27.
//

import Foundation
var all_chat_message_model: [Single_chat_history_model] = load_all_chat_history()


