//
//  All_posts_model.swift
//  temp
//
//  Created by administrator-zou on 2022/3/26.
//

import Foundation
var All_posts_model: [Single_post_model] = load_posts()

