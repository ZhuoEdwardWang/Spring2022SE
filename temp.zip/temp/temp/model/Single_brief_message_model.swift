//
//  Single_message_model.swift
//  temp
//
//  Created by administrator-zou on 2022/3/26.
//

import Foundation
import SwiftUI
struct Single_brief_message_model:Identifiable{
    //The message ID
    //Should be unique for each pair of users
    var id: Int
    var name: String
    var last_message: String
    var last_message_time: Date
    
    var picture: Image
    
    init(_ id: Int, _ name: String, _ last_message: String, _ last_message_time: Date, _ picture: Image) {
        self.id = id
        self.name = name
        self.last_message = last_message
        self.last_message_time = last_message_time
        self.picture = picture
    }
}

